%
% This Code enherent from the code developed by Yarpiz (www.yarpiz.com)
% The code optimised the MFC patch position on fan blade for active
% vibration control
% Author: Kouider Bendine
% Contact Info: bendinekouider@gmail.com
%

clc;
clear;
close all;

%% Problem Definiton

problem.CostFunction = @(x) ObjectiveFunction(x);  % Cost Function
problem.nVar = 5;       % Number of Unknown (Decision) Variables
problem.VarMin =  1;    % Lower Bound of Decision Variables
problem.VarMax =  15;   % Upper Bound of Decision Variables

%% Parameters of PSO

params.MaxIt = 100;        % Maximum Number of Iterations
params.nPop = 10;           % Population Size (Swarm Size)
params.w = 1;               % Intertia Coefficient
params.wdamp = 0.99;        % Damping Ratio of Inertia Coefficient
params.c1 = 2;              % Personal Acceleration Coefficient
params.c2 = 2;              % Social Acceleration Coefficient
params.ShowIterInfo = true; % Flag for Showing Iteration Informatin

%% Calling PSO
myVideo = VideoWriter([num2str(problem.nVar ),'myVideoBlade']); %open video file
myVideo.FrameRate =2;  %can adjust this, 5 - 10 works well for me
open(myVideo)

out = PSO(problem, params,myVideo );
close(myVideo)
BestSol = out.BestSol;
BestCosts = out.BestCosts;

%% Results

%figure(2);
% plot(BestCosts, 'LineWidth', 2);
%semilogy(BestCosts, 'LineWidth', 2);
%xlabel('Iteration');
%ylabel('Best Cost');
grid on;


