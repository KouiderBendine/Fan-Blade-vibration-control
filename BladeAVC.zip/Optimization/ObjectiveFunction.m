
% Object function based on controllablity gramian

function [ Fitn ] = ObjectiveFunction(x)

qessi = 0.01;
RandPatch = x;
NPatch = length(x);     
B_Matrix = xlsread('OnePatchBMatrix.xlsx');
A_vect = [31.619, 71.367, 96.244, 275.74...
         ,384.98,562.44];
N_Mode = length(A_vect);

 
% Calculate The fitness function
    LamdaS = 0;
    LamdaP = 1;

for N=1:N_Mode   
    
    
        LamdaS = LamdaS + sum((B_Matrix (N, RandPatch)).^2) / (4 * qessi * 2 * pi * A_vect(N));
    
        LamdaP = LamdaP * sum((B_Matrix (N, RandPatch)).^2) / (4 * qessi * 2 * pi * A_vect(N));
    
end
        Fitn = LamdaS * (LamdaP) ^ (1 / N_Mode);
end