import subprocess
import csv
import numpy as np
import matplotlib.pyplot as plt
import xlsxwriter



Patch_Number = 1
Population = 20000
qessi = 0.019
N_Mode = 6
Pos_vect = np.zeros((15, 1))
Fitness  = np.zeros((15,  1))
B_total  = np.zeros((6, 15))
count = 0
## Start The FEM iteration analysis

for it in range(15):
    print('Runtine', it)
    Pos_vect[it] = it+1
    file1 = open("Iter_param.inp", "w+")
    file1.write('iter=%e\n' % Pos_vect[it])
    file1.close()
    if it <= 9:
        cmd = ["C:\Program Files\ANSYS Inc\\v201\\ansys\\bin\winx64\ANSYS201.exe", '-b', '-p', 'ANSYS', '-i',
               'D:\Zhang_China\Blade_Model_Optim.txt', '-o',
               'D:\Zhang_China\\ansys_out.txt']
        subprocess.call(cmd)
    else:
        cmd = ["C:\Program Files\ANSYS Inc\\v201\\ansys\\bin\winx64\ANSYS201.exe", '-b', '-p', 'ANSYS', '-i',
               'D:\Zhang_China\Blade_Model_Optim_overlap.txt', '-o',
               'D:\Zhang_China\\ansys_out.txt']
        subprocess.call(cmd)
    print('Patch_loc', '|--> '+str(it+1))
    ## Read The Output Results
    with open('State_Space.csv', 'r') as csv_file:
        csv_reader = csv.reader(csv_file)
        i = 0
        Total_vec = np.zeros((4, 12))
        for line in csv_reader:
            Total_vec[i, :] = np.matrix(line)
            i = i + 1

    B_vect = Total_vec[:, 0:6]
    A_vect = Total_vec[:, 6:12]
    B_total[:, it] = B_vect[0,:]
        ## Calculate The fitness function
    LamdaS = 0
    LamdaP = 1
    for N in range(N_Mode):
        LamdaS = LamdaS + np.sum(np.square(B_vect[:, N])) / (4 * qessi * 2 * np.pi * A_vect[0, N])
        LamdaP = LamdaP * np.sum(np.square(B_vect[:, N])) / (4 * qessi * 2 * np.pi * A_vect[0, N])
    Fitness[it] = LamdaS * (LamdaP) ** (1 / N_Mode)
    count = count+1



# Save the best results
workbook = xlsxwriter.Workbook('OnePatchFitness.xlsx')
worksheet = workbook.add_worksheet()



for col, data in enumerate(list(Pos_vect)):
    worksheet.write(0, col, data)
for col, data in enumerate(list(Fitness)):
    worksheet.write(1, col, data)

workbook.close()


# Save the B matrix results
workbook = xlsxwriter.Workbook('OnePatchBMatrix.xlsx')
worksheet = workbook.add_worksheet()

B_Global = np.zeros((6, 15))
for i in range(15):
    B_Global[:, i] = B_total[:, i]

for col, data in enumerate(list(B_Global[0, :])):
    worksheet.write(0, col, data)
for col, data in enumerate(list(B_Global[1, :])):
    worksheet.write(1, col, data)
for col, data in enumerate(list(B_Global[2, :])):
    worksheet.write(2, col, data)
for col, data in enumerate(list(B_Global[3, :])):
    worksheet.write(3, col, data)
for col, data in enumerate(list(B_Global[4, :])):
    worksheet.write(4, col, data)
for col, data in enumerate(list(B_Global[5, :])):
    worksheet.write(5, col, data)

workbook.close()



